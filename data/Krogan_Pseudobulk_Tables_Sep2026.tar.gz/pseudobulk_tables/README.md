# Pseudobulk tables — MDA-MB-468 CRISPRi Perturb-seq, DMSO vs Vorinostat

Generated 2026-09-19 by `notebooks/verify_and_export_pseudobulk.py`.
These are the per-transcript, per-treatment, per-perturbation tables underlying every
concordance number in the September 2026 report.

## One thing to note about the gene set

The request mentioned "2000 HVGs". **There is no 2000-gene set in this analysis.** The
canonical basis is the **union of the top-1000 most variable genes per condition**, which
is **1861 genes** (DMSO 1000 ∪ Vorinostat 1000; their intersection is 139, and
1861 + 139 = 2000, which may be where the figure came from). All tables here use those
1861 genes. A 3669-gene `Union 2000` set also exists in the sensitivity sweep if a larger
basis is wanted.

## Files

| File | Shape | What it is |
|---|---|---|
| `Pseudobulk_RawCounts_Union1K_{DMSO,Vorino}.csv` | 1861 × 109 / 110 | Integer UMI counts, summed over the cells of each perturbation |
| `Pseudobulk_MeanCountsPerCell_Union1K_{…}.csv` | 1861 × 109 / 110 | The above ÷ cells per perturbation |
| `Pseudobulk_CPMlog1p_Union1K_{…}.csv` | 1861 × 109 / 110 | CPM-normalised, log1p, then averaged per perturbation |
| `Pseudobulk_ZNormToNTC_Union1K_{…}.csv` | 1861 × 109 / 110 | **The matrix correlations are computed from** |
| `NTC_Reference_Union1K.csv` | 1861 × 4 | Per-gene NTC mean and sd used for the Z-normalisation |
| `CellsPerPerturbation.csv` | 219 rows | Cells per perturbation per condition, plus `in_shared_set` |
| `CorrelationMatrix_Union1K_{DMSO,Vorino}.csv` | 106 × 106 | Pearson correlation between every pair of perturbations |

Rows are gene symbols; columns are perturbed genes (the CRISPRi target).

## How the numbers chain together

```
raw counts  --(/n_cells)-->  mean counts per cell
raw counts  --(CPM, log1p, mean over cells)-->  CPMlog1p
CPMlog1p    --((x - NTC_mean) / NTC_sd)-->  ZNormToNTC
ZNormToNTC  --(Pearson across the 1861 genes)-->  CorrelationMatrix
```

Each step is reproducible from the file before it. Verified: recomputing Pearson from
`Pseudobulk_ZNormToNTC_*` reproduces every published correlation to 1.7e-07 (the CSV is
written at 6 significant figures) and returns **exactly** the published 54/83 concordance
with identical per-pair calls.

## Counts

- **Cells**: DMSO 7,402 (7,069 perturbed + 333 NTC); Vorinostat 6,135 (5,874 + 261)
- **Perturbations**: DMSO 109, Vorinostat 110, **106 shared** — only the shared ones can
  enter a cross-condition correlation
- **Genes**: 35,204 measured; 1,861 in the Union-1K basis used here
- Cells per perturbation: median 61, range 7–107

## Caveats worth knowing before reconciling numbers

**1. Seven library genes are missing from one condition**, so they cannot be correlated
across conditions: `CUL3`, `RREB1`, `SHROOM3`, `SRGAP2` have no DMSO data; `HCFC1`,
`HTATSF1`, `KMT2D` have no Vorinostat data. This is why 91 differential PPI pairs reduce
to the **83** that are actually scored. The DEG-Jaccard analysis drops the identical
8 pairs.

**2. 320 of the 1861 genes have an NTC standard deviation of exactly zero** in at least
one condition — they were never detected in the 333 / 261 NTC cells. For those the
normalisation divides by a fallback value of 1, so the column is a mean-centred CPM value
rather than a true Z-score. `NTC_Reference_Union1K.csv` carries the sd so these are
identifiable. Dropping all 320 moves concordance from 54/83 (65.1%, p=0.0040) to
53/83 (63.9%, p=0.0076), so the result does not depend on them. No gene is divided by a
near-zero sd: the smallest non-zero NTC sd among these 1861 genes is 0.13.

**3. Four scored pairs involve a perturbation with fewer than 20 cells**
(`YWHAQ–FAM184B`, `PRMT1–FAM184B`, `MSL1–HIP1`, `YWHAQ–PFKFB2`). Those pseudobulk
profiles are noisy. Restricting to pairs where both perturbations have ≥30 cells gives
49/69 = 71.0% (p=0.0003), i.e. the low-count pairs dilute the signal rather than create
it.

**4. `PRMT1–FAM184B` is a knife-edge call**: Δr = −6.9 × 10⁻⁵, counted concordant, and
FAM184B has only 15 Vorinostat cells. Treat that single call as arbitrary.

## What the concordance statistic is

For each AP-MS bait–prey pair, take the Pearson correlation between the two knockdowns'
profiles in each condition, and ask whether Δr = r(Vorinostat) − r(DMSO) moves the way
the AP-MS `mssEffect` predicts (`up`/`gained` → Δr > 0; `down`/`lost` → Δr < 0).
Positive-control pairs (`mssEffect == "insig"`) are excluded from every statistic.

**Important caveat on interpretation**: correlations rose globally under Vorinostat —
55 of the 83 pairs have Δr > 0 regardless of AP-MS label. The concordance result clears
label-permutation (p=0.010) and random-gene-pair (p=0.008) nulls but **does not clear a
cell-shuffle null (p=0.108)**, which rebuilds the whole correlation structure from
randomised perturbation identity and still reaches 58.3% concordance. See §04 of the
report.
